# pages/admin.py
from django import forms
from django.contrib import admin
from django.core.mail import send_mail
from django.utils import timezone
from django.utils.safestring import mark_safe

from .models import Blog, Profile, ProfileImage

# ─────────────────────────────────────────────────────────────
# Blog (exactly like you had)
# ─────────────────────────────────────────────────────────────
@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    list_display = ("title", "status", "published_at", "created_at", "updated_at")
    list_filter = ("status", "published_at", "created_at")
    search_fields = ("title", "summary", "content")
    prepopulated_fields = {"slug": ("title",)}
    ordering = ("-published_at", "-created_at")
    readonly_fields = ("created_at", "updated_at")

    fieldsets = (
        ("Content", {"fields": ("title", "slug", "summary", "content", "hero_image")}),
        ("Publishing", {"fields": ("status", "published_at", "created_at", "updated_at")}),
    )

    actions = ["publish_now", "mark_scheduled", "mark_draft"]

    @admin.action(description="Publish now (set status=published & published_at=now)")
    def publish_now(self, request, queryset):
        queryset.update(status=Blog.Status.PUBLISHED, published_at=timezone.now())

    @admin.action(description="Mark as scheduled (keep published_at as set)")
    def mark_scheduled(self, request, queryset):
        queryset.update(status=Blog.Status.SCHEDULED)

    @admin.action(description="Mark as draft")
    def mark_draft(self, request, queryset):
        queryset.update(status=Blog.Status.DRAFT)


# ─────────────────────────────────────────────────────────────
# Profiles + inline images, with review/approval & email action
# ─────────────────────────────────────────────────────────────
class ProfileImageInline(admin.TabularInline):
    model = ProfileImage
    extra = 0
    fields = ("image", "is_primary", "is_private", "created_at")
    readonly_fields = ("created_at",)


class RequestChangesForm(forms.Form):
    subject = forms.CharField(
        label="Email subject",
        initial="We need a quick update to your GR8DATE profile",
        max_length=200,
        widget=forms.TextInput(attrs={"style": "width: 60%"}),
    )
    reason = forms.CharField(
        label="What to change (email body)",
        widget=forms.Textarea(attrs={"rows": 6, "style": "width: 80%"}),
        help_text="Explain what the user should change. A link to finish their profile will be included.",
    )
    # Optional flag flips after emailing
    mark_incomplete = forms.BooleanField(
        required=False, initial=False, label="Mark profile incomplete after emailing"
    )
    revoke_approval = forms.BooleanField(
        required=False, initial=False, label="Revoke approval after emailing"
    )


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    # No preferred-age columns; lean list for moderation
    list_display = (
        "id",
        "user_username",
        "user_email",
        "is_complete",
        "is_approved",
        "location",
        "preview_profile_link_short",
    )
    list_filter = ("is_complete", "is_approved", "location")
    search_fields = ("user__username", "user__email", "headline", "about", "location")
    ordering = ("-id",)
    inlines = [ProfileImageInline]

    fieldsets = (
        ("User", {"fields": ("user",)}),
        ("Status", {"fields": ("is_complete", "is_approved")}),
        ("Basics", {"fields": ("headline", "about", "location", "date_of_birth")}),
        ("Preferences (optional)", {
            "classes": ("collapse",),
            "fields": (
                "my_gender",
                "looking_for",
                "children",
                "my_interests",
                "must_have_tags",
                "preferred_age_min",
                "preferred_age_max",
                "preferred_distance",
                "preferred_intent",
            ),
        }),
        ("Review", {"fields": ("preview_profile_link",)}),
    )
    readonly_fields = ("preview_profile_link",)

    # Actions: quick approve/revoke + email request changes
    actions = (
        "action_mark_complete",
        "action_approve",
        "action_approve_and_complete",
        "action_revoke_approval",
        "action_request_changes_email",
    )

    # ----- List helpers -----
    @admin.display(description="Username")
    def user_username(self, obj):
        return getattr(obj.user, "username", "")

    @admin.display(description="Email")
    def user_email(self, obj):
        return getattr(obj.user, "email", "")

    @admin.display(description="Preview")
    def preview_profile_link_short(self, obj):
        url = f"/profile/{obj.pk}/"
        return mark_safe(f'<a href="{url}" target="_blank">Open</a>')

    @admin.display(description="Preview profile (opens new tab)")
    def preview_profile_link(self, obj):
        url = f"/profile/{obj.pk}/"
        return mark_safe(f'<a href="{url}" target="_blank" rel="noopener">/profile/{obj.pk}/</a>')

    # ----- Quick flag actions -----
    @admin.action(description="Mark selected as complete")
    def action_mark_complete(self, request, queryset):
        updated = queryset.update(is_complete=True)
        self.message_user(request, f"Marked {updated} profile(s) as complete.")

    @admin.action(description="Approve selected")
    def action_approve(self, request, queryset):
        updated = queryset.update(is_approved=True)
        self.message_user(request, f"Approved {updated} profile(s).")

    @admin.action(description="Approve + Mark complete")
    def action_approve_and_complete(self, request, queryset):
        updated = queryset.update(is_approved=True, is_complete=True)
        self.message_user(request, f"Approved & completed {updated} profile(s).")

    @admin.action(description="Revoke approval")
    def action_revoke_approval(self, request, queryset):
        updated = queryset.update(is_approved=False)
        self.message_user(request, f"Revoked approval for {updated} profile(s).")

    # ----- Email "request changes" with intermediate form -----
    @admin.action(description="Request changes (email user…)")
    def action_request_changes_email(self, request, queryset):
        """
        Shows a form (subject + reason) then emails each selected user's email.
        Also supports flipping flags after emailing.
        """
        # Step 1: show form if not submitted yet
        if "apply" not in request.POST:
            form = RequestChangesForm()
            return admin.helpers.render_action_form(
                request,
                context={
                    "action_checkbox_name": admin.helpers.ACTION_CHECKBOX_NAME,
                    "form": form,
                    "title": "Email users to request profile changes",
                    "queryset": queryset,
                },
            )

        # Step 2: form submitted → validate and send
        form = RequestChangesForm(request.POST)
        if not form.is_valid():
            return admin.helpers.render_action_form(
                request,
                context={
                    "action_checkbox_name": admin.helpers.ACTION_CHECKBOX_NAME,
                    "form": form,
                    "title": "Email users to request profile changes",
                    "queryset": queryset,
                },
            )

        subject = form.cleaned_data["subject"]
        reason = form.cleaned_data["reason"]
        mark_incomplete = form.cleaned_data["mark_incomplete"]
        revoke_approval = form.cleaned_data["revoke_approval"]

        sent = 0
        for profile in queryset.select_related("user"):
            email = getattr(profile.user, "email", None)
            if not email:
                continue

            # include a direct link to finish profile
            finish_url = "/profile/create/"
            body = (
                f"Hi {profile.user.username},\n\n"
                f"Thanks for joining GR8DATE. We need a quick update to your profile:\n\n"
                f"{reason}\n\n"
                f"You can make the change here: {finish_url}\n\n"
                f"Thanks,\nGR8DATE Team"
            )

            try:
                send_mail(subject, body, None, [email], fail_silently=False)
                sent += 1
            except Exception as e:
                # still continue with the rest
                self.message_user(request, f"Failed to email {email}: {e}", level="error")

            # Optional flag flips
            dirty = False
            if mark_incomplete and profile.is_complete:
                profile.is_complete = False
                dirty = True
            if revoke_approval and profile.is_approved:
                profile.is_approved = False
                dirty = True
            if dirty:
                profile.save(update_fields=["is_complete", "is_approved"])

        self.message_user(request, f"Emailed {sent} user(s) with change requests.")


# Optional: a simple list admin for images
@admin.register(ProfileImage)
class ProfileImageAdmin(admin.ModelAdmin):
    list_display = ("id", "profile_id_display", "is_primary", "is_private", "created_at")
    list_filter = ("is_primary", "is_private")
    search_fields = ("profile__user__username", "profile__user__email")
    readonly_fields = ("created_at",)

    @admin.display(description="Profile ID")
    def profile_id_display(self, obj):
        return getattr(obj.profile, "id", None)


# ─────────────────────────────────────────────────────────────
# Users admin without First/Last name columns (optional)
# ─────────────────────────────────────────────────────────────
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin

User = get_user_model()
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass


@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    list_display = ("username", "email", "is_active", "is_staff", "is_superuser", "last_login", "date_joined")
    ordering = ("-date_joined",)
    search_fields = ("username", "email")
    list_filter = ("is_staff", "is_superuser", "is_active", "groups")

