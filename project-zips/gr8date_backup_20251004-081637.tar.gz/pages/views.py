# pages/views.py
from __future__ import annotations

from datetime import date
from typing import Optional

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Prefetch
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views.generic import ListView, DetailView

from .models import Blog, Profile, ProfileImage

User = get_user_model()


# ============================================================================
# Blog
# ============================================================================
class BlogListView(ListView):
    template_name = "pages/blog_list.html"
    model = Blog
    context_object_name = "posts"
    paginate_by = 12

    def get_queryset(self):
        now = timezone.now()
        return (
            Blog.objects.filter(status=Blog.Status.PUBLISHED, published_at__lte=now)
            .order_by("-published_at", "-created_at")
        )


class BlogDetailView(DetailView):
    template_name = "pages/blog_detail.html"
    model = Blog
    context_object_name = "post"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_queryset(self):
        qs = Blog.objects.all()
        if self.request.user.is_staff:
            return qs
        now = timezone.now()
        return qs.filter(status=Blog.Status.PUBLISHED, published_at__lte=now)


# ============================================================================
# Helpers
# ============================================================================
def _ensure_profile(user) -> Profile:
    try:
        return user.profile
    except Profile.DoesNotExist:
        return Profile.objects.create(user=user)


def _allow_full_access(profile: Profile) -> bool:
    """
    Full dashboard access only if profile is_complete AND is_approved.
    """
    is_complete = getattr(profile, "is_complete", False)
    approved = getattr(profile, "is_approved", False)
    return bool(is_complete and approved)


def _age_from_dob(dob: Optional[date]) -> Optional[int]:
    if not dob:
        return None
    today = date.today()
    years = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    return max(0, years)


def _primary_image_url(profile: Profile) -> Optional[str]:
    """
    First public primary image URL, then any public image, else None.
    Relies on ProfileImage FK related_name='images'.
    """
    images = getattr(profile, "images_cached", None)
    if images is None:
        images = ProfileImage.objects.filter(profile=profile, is_private=False).order_by(
            "-is_primary", "-created_at"
        )
    primary = next((im for im in images if getattr(im, "is_primary", False)), None)
    if primary and primary.image:
        return primary.image.url
    any_img = next((im for im in images if im.image), None)
    return any_img.image.url if any_img else None


# ============================================================================
# Auth handlers (NO template changes)
# ============================================================================
def auth_login_view(request):
    """
    Handles POSTs from templates/pages/login_gr8date_user_or_email_showpw.html
    Fields: identifier (username or email), password
    """
    if request.method != "POST":
        return render(request, "pages/login_gr8date_user_or_email_showpw.html")

    ident = (request.POST.get("identifier") or request.POST.get("username") or "").strip()
    password = (request.POST.get("password") or "").strip()

    # If email supplied, resolve to username for auth
    username = ident
    if "@" in ident:
        try:
            user_obj = User.objects.get(email__iexact=ident)
            username = user_obj.username
        except User.DoesNotExist:
            pass  # let authenticate() fail uniformly

    user = authenticate(request, username=username, password=password)
    if user is None:
        messages.error(request, "Invalid credentials. Please try again.")
        return redirect("login")

    login(request, user)
    prof = _ensure_profile(user)
    return redirect("dashboard" if _allow_full_access(prof) else "preview")


def auth_signup_view(request):
    """
    Handles POSTs from templates/pages/join_gr8date_singlepw_show.html
    Fields: email, password
    Auto-generates a unique username from the email local-part.
    """
    if request.method != "POST":
        return render(request, "pages/join_gr8date_singlepw_show.html")

    email = (request.POST.get("email") or "").strip()
    password = (request.POST.get("password") or "").strip()

    if not email or not password:
        messages.error(request, "Please provide both email and password.")
        return redirect("join")

    if User.objects.filter(email__iexact=email).exists():
        messages.error(request, "An account with that email already exists. Try logging in.")
        return redirect("login")

    base = email.split("@", 1)[0] or "user"
    candidate = base
    i = 1
    while User.objects.filter(username__iexact=candidate).exists():
        i += 1
        candidate = f"{base}{i}"

    user = User.objects.create_user(username=candidate, email=email, password=password)
    _ensure_profile(user)
    login(request, user)
    return redirect("preview")


# ============================================================================
# Logout
# ============================================================================
def logout_view(request):
    logout(request)
    return redirect("home")


# ============================================================================
# Preview gate → Dashboard → Create / Preview my profile
# ============================================================================
def preview_gate(request):
    """Landing page for verified-but-not-yet-approved users (or just joined)."""
    return render(request, "pages/gr8date_preview_gate.html")


@login_required
def dashboard(request):
    """
    Dashboard in two modes:
    - preview_mode=True  → locked actions; only Dashboard/Logout icons work
    - preview_mode=False → full access
    Shows 12 profiles/page (only approved+complete profiles are listed).
    """
    me = _ensure_profile(request.user)
    preview_mode = not _allow_full_access(me)

    profiles_qs = (
        Profile.objects.select_related("user")
        .prefetch_related(
            Prefetch(
                "images",
                queryset=ProfileImage.objects.filter(is_private=False).order_by(
                    "-is_primary", "-created_at"
                ),
                to_attr="images_cached",
            )
        )
        .order_by("id")
    )

    if hasattr(Profile, "is_approved"):
        profiles_qs = profiles_qs.filter(is_approved=True)
    if hasattr(Profile, "is_complete"):
        profiles_qs = profiles_qs.filter(is_complete=True)

    paginator = Paginator(profiles_qs, 12)
    page_num = request.GET.get("page", 1)
    page_obj = paginator.get_page(page_num)

    # attach computed helpers without clashing with @property
    for p in page_obj.object_list:
        url = _primary_image_url(p)
        if not isinstance(getattr(type(p), "primary_image_url", None), property):
            setattr(p, "primary_image_url", url)
        else:
            setattr(p, "card_image_url", url)  # alternative name if property exists

        age_val = _age_from_dob(getattr(p, "date_of_birth", None))
        if not isinstance(getattr(type(p), "age", None), property):
            setattr(p, "age", age_val)
        else:
            setattr(p, "computed_age", age_val)

    return render(
        request,
        "pages/gr8date_dashboard_fixed_v10_nolines.html",
        {"profiles": page_obj, "preview_mode": preview_mode},
    )


@login_required
def profile_create(request):
    """
    Save minimal profile fields; mark is_complete=True (NOT approved).
    """
    prof = _ensure_profile(request.user)

    if request.method == "POST":
        prof.headline = (request.POST.get("headline") or "").strip()
        prof.location = (request.POST.get("location") or "").strip()
        prof.about = (request.POST.get("about") or "").strip()

        dob_str = (request.POST.get("date_of_birth") or "").strip()
        if dob_str:
            try:
                y, m, d = [int(x) for x in dob_str.split("-")]
                prof.date_of_birth = date(y, m, d)
            except Exception:
                prof.date_of_birth = None

        prof.my_gender = (request.POST.get("my_gender") or "").strip()
        prof.looking_for = (request.POST.get("looking_for") or "").strip()
        prof.children = (request.POST.get("children") or "").strip()
        prof.my_interests = (request.POST.get("my_interests") or "").strip()
        prof.must_have_tags = (request.POST.get("must_have_tags") or "").strip()

        try:
            prof.preferred_age_min = int(
                request.POST.get("pref_age_min")
                or request.POST.get("preferred_age_min")
                or 25
            )
        except Exception:
            prof.preferred_age_min = 25
        try:
            prof.preferred_age_max = int(
                request.POST.get("pref_age_max")
                or request.POST.get("preferred_age_max")
                or 45
            )
        except Exception:
            prof.preferred_age_max = max(prof.preferred_age_min, 45)

        prof.preferred_distance = (
            request.POST.get("preferred_distance")
            or request.POST.get("prefDistance")
            or "Any"
        ).strip()
        prof.preferred_intent = (
            request.POST.get("preferred_intent")
            or request.POST.get("prefIntent")
            or "Any"
        ).strip()

        if hasattr(prof, "is_complete"):
            prof.is_complete = True
        if hasattr(prof, "is_approved"):
            if prof.is_approved is None:
                prof.is_approved = False

        prof.save()

        messages.success(
            request,
            "Your profile has been saved and will be reviewed by our team. "
            "You’ll get full access once approved.",
        )
        return redirect("dashboard")

    return render(
        request,
        "pages/my_profile_create_full_v22_interests_in_lifestyle.html",
        {"me": prof},
    )


@login_required
def profile_preview(request):
    me = _ensure_profile(request.user)
    lock = not _allow_full_access(me)
    context = {
        "me": me,
        "age": _age_from_dob(getattr(me, "date_of_birth", None)),
        "public_images": ProfileImage.objects.filter(profile=me, is_private=False)
        .order_by("-is_primary", "-created_at")[:4],
        "private_images": ProfileImage.objects.filter(profile=me, is_private=True)
        .order_by("-created_at")[:4],
        "preview_mode": lock,
        "lock_media": lock,
    }
    return render(
        request,
        "pages/gr8date_profile_flexible_lightbox_fix_navbars_centered_red_smaller.html",
        context,
    )


# ============================================================================
# Public/read-only profile page (by id) — for Admin “Open” and preview users
# ============================================================================
def profile_public(request, pk: int):
    prof = get_object_or_404(Profile.objects.select_related("user"), pk=pk)

    public_images = ProfileImage.objects.filter(profile=prof, is_private=False).order_by(
        "-is_primary", "-created_at"
    )[:8]
    private_images = ProfileImage.objects.filter(profile=prof, is_private=True).order_by(
        "-created_at"
    )[:8]

    viewer_preview = True
    if request.user.is_authenticated:
        try:
            vp = request.user.profile
            viewer_preview = not (
                getattr(vp, "is_complete", False) and getattr(vp, "is_approved", False)
            )
        except Profile.DoesNotExist:
            viewer_preview = True

    ctx = {
        "me": prof,  # your template expects 'me'
        "age": _age_from_dob(getattr(prof, "date_of_birth", None)),
        "public_images": public_images,
        "private_images": private_images,
        "preview_mode": viewer_preview,
        "lock_media": viewer_preview,
    }
    return render(
        request,
        "pages/gr8date_profile_flexible_lightbox_fix_navbars_centered_red_smaller.html",
        ctx,
    )


# ============================================================================
# Icon target placeholders (existing templates)
# ============================================================================
@login_required
def search_view(request):
    return render(request, "pages/search.html")


@login_required
def messages_view(request):
    return render(request, "pages/admin_messages_inbox_wireframe.html")


@login_required
def matches_view(request):
    return render(request, "pages/matches.html")


@login_required
def hotdates_list(request):
    return render(request, "pages/hotdate_server_list.html")


@login_required
def hotdates_create(request):
    return render(request, "pages/hotdate_server_create.html")


@login_required
def account_settings(request):
    return render(request, "pages/account_settings.html")

