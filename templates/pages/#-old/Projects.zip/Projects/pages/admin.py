from django.contrib import admin
from django.utils import timezone
from .models import Blog

@admin.register(Blog)
class BlogAdmin(admin.ModelAdmin):
    list_display = ("title", "status", "published_at", "created_at", "updated_at")
    list_filter = ("status", "published_at", "created_at")
    search_fields = ("title", "summary", "content")
    prepopulated_fields = {"slug": ("title",)}
    ordering = ("-published_at", "-created_at")
    readonly_fields = ("created_at", "updated_at")

    fieldsets = (
        ("Content", {
            "fields": ("title", "slug", "summary", "content", "hero_image")
        }),
        ("Publishing", {
            "fields": ("status", "published_at", "created_at", "updated_at")
        }),
    )

    actions = ["publish_now", "mark_scheduled", "mark_draft"]

    @admin.action(description="Publish now (set status=published & published_at=now)")
    def publish_now(self, request, queryset):
        queryset.update(status=Blog.Status.PUBLISHED, published_at=timezone.now())

    @admin.action(description="Mark as scheduled (keep published_at as set)")
    def mark_scheduled(self, request, queryset):
        queryset.update(status=Blog.Status.SCHEDULED)

    @admin.action(description="Mark as draft")
    def mark_draft(self, request, queryset):
        queryset.update(status=Blog.Status.DRAFT)

