# pages/views.py
from __future__ import annotations

from datetime import date
from typing import Optional

from django.apps import apps
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Prefetch
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.template import TemplateDoesNotExist
from django.template.loader import get_template
from django.utils import timezone
from django.views.decorators.http import require_http_methods
from django.views.generic import ListView, DetailView
from django.middleware.csrf import get_token

from .models import Blog, Profile, ProfileImage

User = get_user_model()


# ============================================================================
# Blog
# ============================================================================
class BlogListView(ListView):
    template_name = "pages/blog_list.html"
    model = Blog
    context_object_name = "posts"
    paginate_by = 12

    def get_queryset(self):
        now = timezone.now()
        return (
            Blog.objects
            .filter(status=Blog.Status.PUBLISHED, published_at__lte=now)
            .order_by("-published_at", "-created_at")
        )


class BlogDetailView(DetailView):
    template_name = "pages/blog_detail.html"
    model = Blog
    context_object_name = "post"
    slug_field = "slug"
    slug_url_kwarg = "slug"

    def get_queryset(self):
        qs = Blog.objects.all()
        if self.request.user.is_staff:
            return qs
        now = timezone.now()
        return qs.filter(status=Blog.Status.PUBLISHED, published_at__lte=now)


# ============================================================================
# Helpers
# ============================================================================
def _ensure_profile(user) -> Profile:
    """Create a Profile for the user if it doesn't exist yet."""
    try:
        return user.profile
    except Profile.DoesNotExist:
        return Profile.objects.create(user=user)


def _allow_full_access(profile: Profile) -> bool:
    """
    Dashboard full mode vs preview mode.
    Consider 'approved' only if both flags are true. Missing attrs default False.
    """
    is_complete = getattr(profile, "is_complete", False)
    approved = getattr(profile, "approved", False)
    return bool(is_complete and approved)


def _age_from_dob(dob: Optional[date]) -> Optional[int]:
    if not dob:
        return None
    today = date.today()
    years = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
    return max(0, years)


def _primary_image_url(profile: Profile) -> Optional[str]:
    """
    Returns the first public primary image url, then any public image, else None.
    Works with ProfileImage(image, FK profile).
    """
    images = getattr(profile, "images_cached", None)
    if images is None:
        images = ProfileImage.objects.filter(profile=profile, is_private=False).order_by(
            "-is_primary", "-created_at"
        )
    primary = next((im for im in images if getattr(im, "is_primary", False)), None)
    if primary and primary.image:
        return primary.image.url
    any_img = next((im for im in images if im.image), None)
    return any_img.image.url if any_img else None


# ============================================================================
# Auth-lite: login / signup / logout
# ============================================================================
def _first_post_value(request, *names, default=""):
    """Return the first non-empty POST value among the given names."""
    for n in names:
        v = request.POST.get(n)
        if v:
            v = v.strip()
            if v:
                return v
    return default


def auth_login_view(request):
    """
    Robust login (no password change needed):
      - identifier in: username/ident/email/user_or_email/login/handle/uid/user/identifier
      - password in:   password/pass/pwd
      - Unicode NFC normalize both fields
      - Drop zero-width chars and NBSP, trim edges
      - Resolve email→username, verify with check_password()
    """
    if request.method == "POST":
        def first(*names, default=""):
            for n in names:
                v = request.POST.get(n)
                if v:
                    v = v.strip()
                    if v:
                        return v
            return default

        ident = first("username","ident","email","user_or_email","login","handle","uid","user","identifier")
        password = first("password","pass","pwd")
        raw_pw_copy_for_fallback = password  # keep exact browser value for fallback


        # Fallback: if ident empty, pick first non-password POST value
        if not ident:
            for k, v in request.POST.items():
                if k not in ("password","pass","pwd","csrfmiddlewaretoken","remember","remember_me") and (v or "").strip():
                    ident = v.strip()
                    break

        # === sanitize & normalize ===
        import unicodedata
        ZW = {"\u200b","\u200c","\u200d","\u2060"}  # zero-width
        NBSP = {"\u00A0"}  # non-breaking space

        def sanitize(sval):
            if not sval:
                return sval
            # Normalize to NFC so accents/compat forms are canonical
            sval = unicodedata.normalize("NFC", sval)
            # Drop ZW/NBSP explicitly
            sval = "".join(ch for ch in sval if ch not in ZW and ch not in NBSP)
            # Trim ALL unicode whitespace at edges only
            sval = sval.strip()
            return sval

        ident = sanitize(ident)
        password = sanitize(password)

        from django.contrib.auth import get_user_model, login
        from django.shortcuts import redirect
        from django.contrib import messages
        User = get_user_model()

        # Resolve user by email or username (case-insensitive)
        user = None
        if ident:
            if "@" in ident:
                user = User.objects.filter(email__iexact=ident).first()
            if not user:
                user = User.objects.filter(username__iexact=ident).first()

        # Verify password: try sanitized first, then raw (in case sanitization removed legit chars)
        ok = False
        if user and getattr(user, 'is_active', True):
            s_ok = user.check_password(password)
            r_ok = False if (raw_pw_copy_for_fallback is None) else user.check_password(raw_pw_copy_for_fallback)
            print('[login] result sanitized/raw:', s_ok, r_ok)
            ok = bool(s_ok or (raw_pw_copy_for_fallback and raw_pw_copy_for_fallback != password and r_ok))
        if ok:
            from django.conf import settings
            login(request, user, backend=settings.AUTHENTICATION_BACKENDS[0])
            # Ensure profile exists; route by approval/completeness
            try:
                prof = user.profile
            except Exception:
                from .models import Profile
                prof = Profile.objects.create(user=user)
            is_complete = bool(getattr(prof, "is_complete", False))
            approved   = bool(getattr(prof, "approved", False))
            return redirect("preview" if not (is_complete and approved) else "dashboard")

        messages.error(request, "Invalid credentials. Please try again.")
        return redirect("login")

    from django.shortcuts import render
    return render(request, "pages/login_gr8date_user_or_email_showpw.html")

def auth_signup_view(request):
    """
    Demo signup: expects username, email, password in POST.
    New users go to preview gate first.
    """
    if request.method == "POST":
        username = (request.POST.get("username") or "").strip()
        email = (request.POST.get("email") or "").strip()
        password = (request.POST.get("password") or "").strip()

        if not username or not email or not password:
            messages.error(request, "All fields are required.")
            return redirect("join")

        if User.objects.filter(username__iexact=username).exists():
            messages.error(request, "That username is taken. Please choose another.")
            return redirect("join")

        if User.objects.filter(email__iexact=email).exists():
            messages.error(request, "An account with that email already exists.")
            return redirect("join")

        user = User.objects.create_user(username=username, email=email, password=password)
        _ensure_profile(user)
        login(request, user)
        return redirect("preview")

    return render(request, "pages/join_gr8date_singlepw_show.html")


@require_http_methods(["GET", "POST"])
@login_required
def logout_view(request):
    """
    GET  -> show confirm (uses pages/logout_confirm.html if present; otherwise inline fallback)
    POST -> log out and redirect home
    """
    if request.method == "POST":
        logout(request)
        messages.success(request, "You’ve been logged out.")
        return redirect("home")

    try:
        get_template("pages/logout_confirm.html")
        return render(request, "pages/logout_confirm.html", {})
    except TemplateDoesNotExist:
        csrf = get_token(request)
        return HttpResponse(
            f"""
<!doctype html>
<html><head><meta charset="utf-8"><title>Confirm logout</title></head>
<body style="font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;">
  <div style="max-width:480px;margin:10vh auto;padding:24px;border:1px solid #ddd;border-radius:12px">
    <h1 style="margin:0 0 12px">Log out?</h1>
    <p style="margin:0 0 20px">You’re about to sign out.</p>
    <form method="post" action="">
      <input type="hidden" name="csrfmiddlewaretoken" value="{csrf}">
      <button type="submit" style="padding:10px 16px;border-radius:8px;border:1px solid #bbb;cursor:pointer">Log out</button>
      <a href="/" style="margin-left:12px">Cancel</a>
    </form>
  </div>
</body></html>
            """,
            content_type="text/html",
        )


# ============================================================================
# Preview gate → Dashboard → Create / Preview my profile
# ============================================================================
def preview_gate(request):
    """Landing page for verified-but-not-yet-approved users (or just joined)."""
    return render(request, "pages/gr8date_preview_gate.html")


@login_required
def dashboard(request):
    """
    Dashboard in two modes:
      preview_mode=True  → locked actions (until approved+complete)
      preview_mode=False → full access
    Shows 12 profiles/page (approved+complete only when flags exist).
    """
    me = _ensure_profile(request.user)
    preview_mode = not _allow_full_access(me)

    # Base queryset
    profiles_qs = Profile.objects.select_related("user").order_by("id")

    # Dynamic prefetch for ProfileImage, regardless of related_name
    try:
        PI = apps.get_model("pages", "ProfileImage")
        fk = next(
            f for f in PI._meta.get_fields()
            if getattr(f, "many_to_one", False) and getattr(f, "related_model", None) is Profile
        )
        accessor = fk.remote_field.get_accessor_name()  # honors related_name or default *_set
        try:
            pi_qs = PI.objects.filter(is_private=False).order_by("-is_primary", "-created_at")
        except Exception:
            pi_qs = PI.objects.filter(is_private=False)
        profiles_qs = profiles_qs.prefetch_related(
            Prefetch(accessor, queryset=pi_qs, to_attr="images_cached")
        )
    except Exception:
        pass

    if hasattr(Profile, "approved"):
        profiles_qs = profiles_qs.filter(approved=True)
    if hasattr(Profile, "is_complete"):
        profiles_qs = profiles_qs.filter(is_complete=True)

    paginator = Paginator(profiles_qs, 12)
    page_obj = paginator.get_page(request.GET.get("page", 1))

    return render(
        request,
        "pages/gr8date_dashboard_fixed_v10_nolines.html",
        {
            "profiles": page_obj,
            "preview_mode": preview_mode,
        },
    )


@login_required
def profile_create(request):
    """
    Save minimal profile fields. Mark is_complete=True (not approved),
    show a success message, keep in preview until approved.
    """
    prof = _ensure_profile(request.user)

    if request.method == "POST":
        prof.headline = (request.POST.get("headline") or "").strip()
        prof.location = (request.POST.get("location") or "").strip()
        prof.about = (request.POST.get("about") or "").strip()

        # DOB handling (YYYY-MM-DD)
        dob_str = (request.POST.get("date_of_birth") or "").strip()
        if dob_str:
            try:
                y, m, d = [int(x) for x in dob_str.split("-")]
                prof.date_of_birth = date(y, m, d)
            except Exception:
                prof.date_of_birth = None

        # My gender & looking for
        prof.my_gender = (request.POST.get("my_gender") or "").strip()
        prof.looking_for = (request.POST.get("looking_for") or "").strip()

        # Lifestyle children
        prof.children = (request.POST.get("children") or "").strip()

        # Interests / preferences
        prof.my_interests = (request.POST.get("my_interests") or "").strip()
        prof.must_have_tags = (request.POST.get("must_have_tags") or "").strip()

        # Preferred ages
        try:
            prof.preferred_age_min = int(request.POST.get("pref_age_min") or request.POST.get("preferred_age_min") or 25)
        except Exception:
            prof.preferred_age_min = 25
        try:
            prof.preferred_age_max = int(request.POST.get("pref_age_max") or request.POST.get("preferred_age_max") or 45)
        except Exception:
            prof.preferred_age_max = max(prof.preferred_age_min, 45)

        # Distance / intent
        prof.preferred_distance = (request.POST.get("preferred_distance") or request.POST.get("prefDistance") or "Any").strip()
        prof.preferred_intent = (request.POST.get("preferred_intent") or request.POST.get("prefIntent") or "Any").strip()

        # Mark profile complete (awaiting admin approval)
        if hasattr(prof, "is_complete"):
            prof.is_complete = True
        if hasattr(prof, "approved"):
            if getattr(prof, "approved", None) is None:
                prof.approved = False

        prof.save()

        messages.success(
            request,
            "Your profile has been saved and will be reviewed by our team. "
            "You’ll get full access once approved."
        )
        return redirect("dashboard")

    return render(request, "pages/my_profile_create_full_v22_interests_in_lifestyle.html", {"me": prof})


@login_required
def profile_preview(request):
    """
    Read-only profile display page using your template.
    """
    me = _ensure_profile(request.user)
    context = {
        "me": me,
        "age": _age_from_dob(getattr(me, "date_of_birth", None)),
        "public_images": ProfileImage.objects.filter(profile=me, is_private=False).order_by("-is_primary", "-created_at")[:4],
        "private_images": ProfileImage.objects.filter(profile=me, is_private=True).order_by("-created_at")[:4],
    }
    return render(request, "pages/gr8date_profile_flexible_lightbox_fix_navbars_centered_red_smaller.html", context)


# ============================================================================
# Icon target pages (canonical names)
# ============================================================================
@login_required
def search_view(request):
    return render(request, "pages/search.html")


@login_required
def messages_view(request):
    return render(request, "pages/admin_messages_inbox_wireframe.html")


@login_required
def matches_view(request):
    return render(request, "pages/matches.html")


@login_required
def hotdates_list(request):
    return render(request, "pages/hotdate_server_list.html")


@login_required
def hotdates_create(request):
    return render(request, "pages/hotdate_server_create.html")


@login_required
def account_settings(request):
    return render(request, "pages/account_settings.html")


# Backwards-compatible aliases
search_page = search_view
messages_inbox = messages_view
matches_page = matches_view
account_settings_page = account_settings

