# pages/models.py

from __future__ import annotations

from datetime import date

from django.conf import settings
from django.db import models
from django.utils import timezone
from django.utils.text import slugify


# ---------------------------------------------------------------------
# Blog (unchanged)
# ---------------------------------------------------------------------
class Blog(models.Model):
    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        SCHEDULED = "scheduled", "Scheduled"
        PUBLISHED = "published", "Published"

    title = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    summary = models.TextField(blank=True)
    content = models.TextField()
    hero_image = models.ImageField(upload_to="blog/", blank=True, null=True)

    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DRAFT)
    published_at = models.DateTimeField(blank=True, null=True, help_text="When this post should go live.")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-published_at", "-created_at"]

    def __str__(self) -> str:
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)[:220]
        super().save(*args, **kwargs)

    @property
    def is_published(self) -> bool:
        if self.status != self.Status.PUBLISHED:
            return False
        if self.published_at is None:
            return False
        return self.published_at <= timezone.now()


# ---------------------------------------------------------------------
# Profiles
# ---------------------------------------------------------------------

User = settings.AUTH_USER_MODEL


def _today() -> date:
    return timezone.localdate()


class Profile(models.Model):
    """User’s dating profile. One-to-one with the auth user."""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")

    # Completion / approval gates
    is_complete = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Basics
    date_of_birth = models.DateField(blank=True, null=True)
    headline = models.CharField(max_length=120, blank=True)   # formerly "tagline"
    location = models.CharField(max_length=120, blank=True)   # formerly "city"
    about = models.TextField(blank=True)                      # long “About me”

    class Gender(models.TextChoices):
        FEMALE = "female", "Female"
        MALE = "male", "Male"
        NON_BINARY = "nonbinary", "Non-binary"
        UNSPECIFIED = "unspecified", "Prefer not to say"

    my_gender = models.CharField(
        max_length=20, choices=Gender.choices, default=Gender.UNSPECIFIED
    )

    class LookingFor(models.TextChoices):
        MALE = "male", "Male"
        FEMALE = "female", "Female"
        BISEXUAL = "bisexual", "Bi-sexual"
        UNSPECIFIED = "unspecified", "Prefer not to say"

    looking_for = models.CharField(
        max_length=20, choices=LookingFor.choices, default=LookingFor.UNSPECIFIED
    )

    class Children(models.TextChoices):
        PREFER_NOT = "prefer_not", "Prefer not to say"
        YES = "yes", "Yes"
        NONE = "none", "None"

    children = models.CharField(
        max_length=20, choices=Children.choices, default=Children.PREFER_NOT
    )

    # Lifestyle / tags (CSV strings)
    my_interests = models.CharField(max_length=600, blank=True)   # e.g. "hiking,coffee,dogs"
    must_have_tags = models.CharField(max_length=600, blank=True)

    # Preferences
    preferred_age_min = models.PositiveSmallIntegerField(default=18)
    preferred_age_max = models.PositiveSmallIntegerField(default=60)

    class Distance(models.TextChoices):
        ANY = "any", "Any"
        KM_5 = "5", "5 km"
        KM_10 = "10", "10 km"
        KM_25 = "25", "25 km"
        KM_50 = "50", "50 km"
        KM_100 = "100", "100 km"
        COUNTRY = "country", "Countrywide"

    preferred_distance = models.CharField(
        max_length=20, choices=Distance.choices, default=Distance.ANY
    )

    class Intent(models.TextChoices):
        ANY = "any", "Any"
        FRIENDS = "friends", "New friends"
        CASUAL = "casual", "Casual dating"
        LONGTERM = "longterm", "Long-term"
        MARRIAGE = "marriage", "Marriage"

    preferred_intent = models.CharField(
        max_length=20, choices=Intent.choices, default=Intent.ANY
    )

    def __str__(self) -> str:
        uname = getattr(self.user, "username", None) or (self.user.get_username() if self.user else "user")
        return f"Profile #{self.pk} (@{uname})"

    # -------- gating logic for dashboard --------
    def allow_full_access(self) -> bool:
        """Full dashboard access only when complete + approved."""
        return bool(self.is_complete and self.is_approved)

    # -------- helpers --------
    @property
    def age(self) -> int | None:
        """Age in years from DOB, or None if unknown."""
        if not self.date_of_birth:
            return None
        today = _today()
        years = today.year - self.date_of_birth.year
        before_bday = (today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day)
        return years - 1 if before_bday else years

    @property
    def primary_image(self) -> "ProfileImage | None":
        return self.images.filter(is_primary=True).first()

    @property
    def primary_image_url(self) -> str | None:
        img = self.primary_image
        try:
            return img.image.url if img else None
        except Exception:
            return None

    # --- backwards-compat properties for older templates ---
    @property
    def display_name(self) -> str:
        """Old templates used {{ me.display_name }} — use username."""
        u = getattr(self, "user", None)
        return getattr(u, "username", "") or (u.get_username() if u else "")

    @property
    def tagline(self) -> str:
        """Old templates used {{ me.tagline }} — map to headline."""
        return self.headline or ""

    @property
    def city(self) -> str:
        """Old templates used {{ me.city }} — map to location."""
        return self.location or ""

    @property
    def bio(self) -> str:
        """Old templates used {{ me.bio }} — map to about."""
        return self.about or ""

    # Optional extra aliases in case older templates reference them:
    @property
    def gender(self) -> str:
        return self.my_gender

    @property
    def pref_age_min(self) -> int:
        return self.preferred_age_min

    @property
    def pref_age_max(self) -> int:
        return self.preferred_age_max

    @property
    def distance(self) -> str:
        return self.preferred_distance

    @property
    def intent(self) -> str:
        return self.preferred_intent


# ---------------------------------------------------------------------
# Profile Images
# ---------------------------------------------------------------------

class ProfileImage(models.Model):
    profile = models.ForeignKey(
        Profile,
        related_name="images",
        on_delete=models.CASCADE,
    )
    image = models.ImageField(upload_to="profiles/")
    is_private = models.BooleanField(default=False)
    is_primary = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["profile"],
                condition=models.Q(is_primary=True),
                name="one_primary_image_per_profile",
            ),
        ]

    def __str__(self) -> str:
        return f"Image #{self.pk} for Profile #{self.profile_id}"

