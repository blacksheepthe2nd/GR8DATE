# core/settings.py
from pathlib import Path

# === Paths ===
BASE_DIR = Path(__file__).resolve().parent.parent

# === Security (DEV ONLY) ===
SECRET_KEY = "dev-secret-key-change-in-prod"
DEBUG = True
ALLOWED_HOSTS = ["localhost", "127.0.0.1", "testserver"]

# === Applications ===
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",

    "pages",  # your app

    # Allauth requirements
    "django.contrib.sites",
    "allauth",
    "allauth.account",
    "allauth.socialaccount",  # fine even if unused
]

# Auth redirects
LOGIN_URL = "/login/"
LOGIN_REDIRECT_URL = "/dashboard/"
LOGOUT_REDIRECT_URL = "/"

# === Middleware ===
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "allauth.account.middleware.AccountMiddleware",   # required by newer allauth
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    "pages.middleware.PreviewLockMiddleware",         # nudges incomplete/unapproved users to preview gate
]

# === URLs / WSGI ===
ROOT_URLCONF = "core.urls"
WSGI_APPLICATION = "core.wsgi.application"

# === Templates ===
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],  # e.g. templates/pages/index.html
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",  # allauth needs this
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

# === Database (SQLite for dev) ===
DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

# === Password validation (fine for dev) ===
AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

# === Authentication backends ===
AUTHENTICATION_BACKENDS = [
    "django.contrib.auth.backends.ModelBackend",
    "pages.auth_backends.EmailOrUsernameModelBackend",
    "allauth.account.auth_backends.AuthenticationBackend",
]

SITE_ID = 1

# ---- Allauth options (updated; replace deprecated ones) ----
# Login can use either username or email (replaces ACCOUNT_AUTHENTICATION_METHOD)
ACCOUNT_LOGIN_METHODS = {"username", "email"}

# We use our own ShimSignupView; disable allauth’s signup UI to avoid conflicts.
# (Keeps your templates unchanged.)
ACCOUNT_SIGNUP_ENABLED = False

# Keep your existing prefs
ACCOUNT_EMAIL_VERIFICATION = "none"
ACCOUNT_PRESERVE_USERNAME_CASING = False
ACCOUNT_SESSION_REMEMBER = True
# (Removed deprecated settings: ACCOUNT_AUTHENTICATION_METHOD, ACCOUNT_EMAIL_REQUIRED, ACCOUNT_USERNAME_REQUIRED)

# === Internationalization ===
LANGUAGE_CODE = "en-au"
TIME_ZONE = "Australia/Sydney"
USE_I18N = True
USE_TZ = True

# === Static & Media ===
STATIC_URL = "static/"
STATICFILES_DIRS = [BASE_DIR / "static"]          # your source static (CSS/JS/images you edit)
STATIC_ROOT = BASE_DIR / "staticfiles"            # where collectstatic gathers for deployment

MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"

# === Default primary key type ===
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

